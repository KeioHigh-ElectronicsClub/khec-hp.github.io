#include "NFCcore7c.h"


bool mfrc522ver7c::setup(byte CS, byte RST, unsigned long SerialSpeed, bool SelectDumpInfo) {
  Serial.begin(SerialSpeed);  //マイコンとのシリアル通信を開始
  while (!Serial);  //ProMicroなどのATMEGA32Uチップマイコンのみ必要(他はあっても問題ない)
  SPI.begin();
  delay(10);
  mfrc522.PCD_Init(CS, RST);  //PCD (Proximity Coupling Device)の初期化
  if (SelectDumpInfo) {
    Serial.println();
    Serial.println(F(">>dumpInfo function > ON"));
    Serial.print(F(">>begin Serial com: Speed > "));
    Serial.println(SerialSpeed);
    Serial.println(F(">>begin SPI com with RC522 module"));
    Serial.println(F(">>initialize nfc_PCD"));
    Serial.print(F(">>"));
    mfrc522.PCD_DumpVersionToSerial();
//    Serial.print(F(">>self perform test result > "));
//    Serial.println(mfrc522.PCD_PerformSelfTest());
//    Serial.print(F(">>antenna's gain > "));
//    Serial.println(mfrc522.PCD_GetAntennaGain());
  }
  dumpInfo = SelectDumpInfo;
  return true;  //いずれNFCモジュールと正しく接続されいるかをbool型で返す
}
bool mfrc522ver7c::waitTouch(unsigned int miliTimeLimit) {
  unsigned int baseTime = millis();
  do {
    Disconnect();
    delay(miliInterval);    //変更可能(タッチ判定の更新速度)
    if ((millis() - baseTime) < miliTimeLimit) return false;
  } while (! mfrc522.PICC_IsNewCardPresent() || ! mfrc522.PICC_ReadCardSerial());
  String strUID;
  for (byte i = 0; i < 4; i++) {
    uid[i] = mfrc522.uid.uidByte[i];
    strUID += String(uid[i], HEX) += " ";
  }
  if (String(uid[0], HEX) == "8") ApplePay = true;
  else ApplePay = false;
  piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
  if (dumpInfo) {
    Serial.println(F(">>NFCtag touched"));
    Serial.print(F("  card UID is "));
    Serial.println(strUID);
    if (ApplePay) Serial.println(F("  >this card type is ApplePay"));
    Serial.print(F("  PICC type: "));
    Serial.print(piccType);
    Serial.print(" >> ");
    Serial.println(mfrc522.PICC_GetTypeName(piccType));
  }
  touched = true;
  return true;
}
bool mfrc522ver7c::waitTouch() {
  unsigned int baseTime = millis();
  do {
    Disconnect();
    delay(miliInterval);    //変更可能(タッチ判定の更新速度)
  } while (! mfrc522.PICC_IsNewCardPresent() || ! mfrc522.PICC_ReadCardSerial());
  String strUID;
  for (byte i = 0; i < 4; i++) {
    uid[i] = mfrc522.uid.uidByte[i];
    strUID += String(uid[i], HEX) += " ";
  }
  if (String(uid[0], HEX) == "8") ApplePay = true;
  else ApplePay = false;
  piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
  if (dumpInfo) {
    Serial.println(F(">>NFCtag touched"));
    Serial.print(F("  card UID is "));
    Serial.println(strUID);
    if (ApplePay) Serial.println(F("  >this card type is ApplePay"));
    Serial.print(F("  PICC type: "));
    Serial.print(piccType);
    Serial.print(" >> ");
    Serial.println(mfrc522.PICC_GetTypeName(piccType));
  }
  touched = true;
  return true;
}
bool mfrc522ver7c::blockRead(byte block) {
  if (dumpInfo) {
    Serial.println(F(">>begin blockRead"));
    Serial.print(F("  use sector "));
    Serial.println((byte)(block / 4));
    Serial.print(F("  block "));
    Serial.println(block);
  }
  if (!authA(block)) return false;
  for (byte i = 0; i < 18; i++) blockReadData[i] = 0; //配列の中身の初期化
  byte  size = 18;
  status = (MFRC522::StatusCode)mfrc522.MIFARE_Read(block, blockReadData, &size);
  if (status != MFRC522::STATUS_OK) {
    if (!dumpInfo) return false;
    Serial.println(F(">>blockRead failed"));
    Serial.println();
    return false;
  }
  if (!dumpInfo) return true;
  Serial.println(F(">>blockRead is in success"));
  Serial.print(F("  result: "));
  for (byte i = 0; i < 16; i++) {
    Serial.print(blockReadData[i]);
    Serial.print(", ");
  }
  Serial.println();
  return true;
}
bool mfrc522ver7c::blockWrite(byte block) {
  if (dumpInfo) {
    Serial.println(F(">>begin blockWrite"));
    Serial.print(F("  using sector "));
    Serial.println((byte)(block / 4));
    Serial.print(F("  using block "));
    Serial.println(block);
    Serial.print(F("  write data "));
    for (byte i = 0; i < 16; i++) {
      Serial.print(blockWriteData[i]);
      Serial.print(", ");  //csv形式変換
    }
    Serial.println();
  }
  if (!authB(block)) return false;
  status = (MFRC522::StatusCode)mfrc522.MIFARE_Write(block, blockWriteData, 16);
  if (status != MFRC522::STATUS_OK) {
    if (!dumpInfo) return false;
    Serial.println(F(">>blockWrite failed"));
    Serial.println();
    return false;
  }
  if (!dumpInfo) return true;
  Serial.println(F("blockWrite is in success"));
  Serial.println();
  return true;
}
bool mfrc522ver7c::sectorRead(byte sector) {
  if (dumpInfo) {
    Serial.println(F(">>begin sectorRead"));
    Serial.print(F("  use sector "));
    Serial.println(sector);
  }
  if (!authA(sector * 4)) return false;
  for (byte j = 0; j < 3; j++) {
    for (byte i = 0; i < 18; i++) sectorReadData[j][i] = 0; //配列の中身の初期化
  }
  for (byte i = 0; i < 3; i++) {
    byte  size = 18;
    status = (MFRC522::StatusCode)mfrc522.MIFARE_Read((byte)(sector * 4 + i), blockReadData, &size);
    if (status != MFRC522::STATUS_OK) {
      if (!dumpInfo) return false;
      Serial.println(F(">>sectorRead failed"));
      Serial.println();
      return false;
    }
    for (byte j = 0; j < 16; j++) {
      sectorReadData[i][j] = blockReadData[j];
    }
  }
  if (!dumpInfo) return true;
  Serial.println(F(">>sectorRead is in success"));
  Serial.println(F("  result: "));
  for (byte j = 0; j < 3; j++) {
    Serial.print(F("        "));
    for (byte i = 0; i < 16; i++) {
      Serial.print(sectorReadData[j][i]);
      Serial.print(", ");
    }
    Serial.println();
  }
  return true;
}
bool mfrc522ver7c::sectorWrite(byte sector) {
  if (dumpInfo) {
    Serial.println(F(">>begin sectorWrite"));
    Serial.print(F("  using sector "));
    Serial.println(sector);
    Serial.print(F("  write data "));
    for (byte j = 0; j < 3; j++) {
      for (byte i = 0; i < 16; i++) {
        Serial.print(sectorWriteData[j][i]);
        Serial.print(", ");  //csv形式変換
      }
      Serial.println();
    }
  }
  if (!authB(sector * 4)) return false;
  for (byte j = 0; j < 3; j++) {
    for (byte i = 0; i < 16; i++) {
      blockWriteData[i] = sectorWriteData[j][i];
    }
    status = (MFRC522::StatusCode)mfrc522.MIFARE_Write((byte)(sector * 4 + j), blockWriteData, 16);
    if (status != MFRC522::STATUS_OK) {
      if (!dumpInfo) return false;
      Serial.println(F(">>sectorWrite failed"));
      Serial.println();
      return false;
    }
  }
  if (!dumpInfo) return true;
  Serial.println(F("sectorWrite is in success"));
  Serial.println();
  return true;
}
void mfrc522ver7c::Disconnect() {
  touched = false;
  mfrc522.PICC_HaltA();             // 接続中の端末との通信を停止
  mfrc522.PCD_StopCrypto1();        // 端末とのPCDの暗号化を停止
}
void mfrc522ver7c::setKeyA(byte block) {
  byte sector = block / 4;
  for (byte i = 0; i < 6; i++) {
    KeyA.keyByte[i] = keyA[sector][i];
  }
  if (dumpInfo) {
    Serial.print(F(">>set keyA data for sector "));
    Serial.println(sector);
    Serial.print(F("  use KeyA: "));
    for (byte i = 0; i < 6; i++) {
      Serial.print(KeyA.keyByte[i]);
      Serial.print(", ");
    }
    Serial.println();
  }
}
void mfrc522ver7c::setKeyB(byte block) {
  byte sector = block / 4;
  for (byte i = 0; i < 6; i++) {
    KeyB.keyByte[i] = keyB[sector][i];
  }
  if (dumpInfo) {
    Serial.print(F(">>set keyB data for sector "));
    Serial.println(sector);
    Serial.print(F("  use KeyB: "));
    for (byte i = 0; i < 6; i++) {
      Serial.print(KeyB.keyByte[i]);
      Serial.print(", ");
    }
    Serial.println();
  }
}
bool mfrc522ver7c::authA(byte block) {
  byte sector = block / 4;
  byte trailerBlock   = sector * 4 + 3;  //そのセクターの認証キーが格納されているブロック番号
  piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
  if (dumpInfo) {
    Serial.println(F(">>start authenticate typeA(read)"));
    Serial.print(F("  piccType: "));
    Serial.println(piccType);
    if (piccType == MFRC522::PICC_TYPE_MIFARE_UL) Serial.println(F(">>skiped authA (because MifareUL)"));
  }
  if (piccType != MFRC522::PICC_TYPE_MIFARE_UL) {
    setKeyA(block);
    status = (MFRC522::StatusCode)mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, trailerBlock, &KeyA, &(mfrc522.uid));
    if (status != MFRC522::STATUS_OK) {
      if (!dumpInfo) return false;
      Serial.println(F(">>authA() failed"));
      Serial.println();
      return false;
    }
    else return true;  //MifareULではなく、認証に成功した場合
  }
  return true;  //MifareULの場合
}
bool mfrc522ver7c::authB(byte block) {
  byte sector = block / 4;
  byte trailerBlock   = sector * 4 + 3;  //そのセクターの認証キーが格納されているブロック番号
  piccType = mfrc522.PICC_GetType(mfrc522.uid.sak);
  if (dumpInfo) {
    Serial.println(F(">>start authenticate typeB(write)"));
    Serial.print(F("  piccType: "));
    Serial.println(piccType);
    if (piccType == MFRC522::PICC_TYPE_MIFARE_UL) Serial.println(F(">>skiped authB (because MifareUL)"));
  }
  if (piccType != MFRC522::PICC_TYPE_MIFARE_UL) {
    setKeyB(block);
    status = (MFRC522::StatusCode)mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_B, trailerBlock, &KeyB, &(mfrc522.uid));
    if (status != MFRC522::STATUS_OK) {
      if (!dumpInfo) return false;
      Serial.println(F(">>authB() failed"));
      Serial.println();
      return false;
    }
    else return true;  //MifareULではなく、認証に成功した場合
  }
  return true;  //MifareULの場合
}
bool mfrc522ver7c::blockReset(byte block) {
  for (byte i = 0; i < 16; i++) {
    blockWriteData[i] = 0;
  }
  if (blockWrite(block)) return true;
  else return false;
}
