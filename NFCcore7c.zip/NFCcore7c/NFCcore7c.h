//2020/08/15更新

#include <MFRC522.h>
#include <SPI.h>
#include "Arduino.h"



class mfrc522ver7c {
    //関数一覧
  public:
    bool setup(byte SDA, byte RST, unsigned long SerialSpeed, bool SelectDumpInfo); //SDA=CS=SS
    bool waitTouch(unsigned int miliTimeLimit);
    bool waitTouch();
    bool blockRead(byte block);
    bool blockWrite(byte block);
    bool sectorRead(byte sector);
    bool sectorWrite(byte sector);
    bool blockReset(byte block);
  private:
    void Disconnect();
    void setKeyA(byte block);
    void setKeyB(byte block);
    bool authA(byte block);
    bool authB(byte block);

    //変数、配列一覧
  public:
    bool ApplePay = false;
    byte blockReadData[18];
    byte sectorReadData[3][18];
    byte blockWriteData[16];
    byte sectorWriteData[3][16];
    byte uid[4];
  private:
    bool dumpInfo = true;
    bool touched = false;
    byte miliInterval = 50;  //waitTouch関数で何ミリ病ごとにカードがかざされているかの判定を行うか
    byte keyA[16][6] = {
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255},
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255},
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255},
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}
    };
    byte keyB[16][6] = {
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255},
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255},
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255},
      {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}, {255, 255, 255, 255, 255, 255}
    };
    MFRC522::StatusCode status;         //ステータス変数を定義
    MFRC522::MIFARE_Key KeyA = {keyByte: {255, 255, 255, 255, 255, 255}};  //デフォルト
    MFRC522::MIFARE_Key KeyB = {keyByte: {255, 255, 255, 255, 255, 255}};  //デフォルト
    MFRC522::PICC_Type piccType;
    MFRC522 mfrc522;   // RC522と接続
};
